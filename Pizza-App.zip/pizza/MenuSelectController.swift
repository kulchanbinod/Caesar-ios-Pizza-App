//
//  MenuSelectController.swift
//  pizza
//
//  Created by bimal pariyar on 9/24/18.
//  Copyright © 2018 Binod Pariyar. All rights reserved.
//

import Foundation
import UIKit

class MenuSelectController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}

