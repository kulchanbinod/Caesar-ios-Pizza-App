//
//  ViewController.swift
//  pizza
//
//  Created by bimal pariyar on 8/7/18.
//  Copyright © 2018 Binod Pariyar. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var invalidLabel: UILabel!
    @IBOutlet weak var login: UIPizzaButton!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        invalidLabel.isHidden = true
    }
    
    @IBAction func LoginBtn(_ sender: Any) {
        
        invalidLabel.isHidden = true
        
        if username.text == "" {
            invalidLabel.text = "Username is required"
            invalidLabel.isHidden = false
            return
        } else {
            if password.text == "" {
                invalidLabel.text = "Password is required"
                invalidLabel.isHidden = false
                return
            }
        }
        
        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let newViewController = storyBoard.instantiateViewController(withIdentifier: "MapController") as! MapController
        self.present(newViewController, animated: true, completion: nil)
    }

    func textFieldDidBeginEditing(_ textField: UITextField) {
        switch textField.tag {
        case 0:
            print("username is selected")
        default:
            scrollView.setContentOffset(CGPoint(x: 0, y: 100), animated: true)
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        scrollView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField.tag == 0 {
            password.becomeFirstResponder()
        } else if textField.tag == 1 {
            textField.resignFirstResponder()
        }
        return true
    }
}
